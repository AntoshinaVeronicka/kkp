
from datetime import datetime
from zoneinfo import ZoneInfo
import os
import re
import uuid

from flask import Flask, render_template, request, redirect, url_for, session, flash, get_flashed_messages
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename

from io import BytesIO
from flask import send_file
from openpyxl import Workbook
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfgen import canvas
from sqlalchemy import text

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///store.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'supersecretkey'

app.config['UPLOAD_FOLDER'] = os.path.join('static', 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024
db = SQLAlchemy(app)

VLADIVOSTOK_TZ = ZoneInfo("Asia/Vladivostok")


def now_vladivostok():
    return datetime.now(VLADIVOSTOK_TZ)

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(50), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # admin / ip


class Category(db.Model):
    __tablename__ = 'categories'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)

    products = db.relationship('Product', backref='category', lazy=True)

class Product(db.Model):
    __tablename__ = 'products'

    id = db.Column(db.Integer, primary_key=True)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=False)
    warehouse_id = db.Column(db.String(50), nullable=True)
    manufacturer = db.Column(db.String(100), nullable=False)
    model = db.Column(db.String(255), nullable=False)
    purchase_price = db.Column(db.Numeric(10, 2), nullable=True)
    image_path = db.Column(db.Text, nullable=True)
    specifications = db.Column(db.Text, nullable=True)
    condition_rate = db.Column(db.Integer, nullable=False)
    current_status = db.Column(db.String(50), nullable=False)
    comments = db.Column(db.Text, nullable=True)

    status_history = db.relationship(
        'ProductStatusHistory',
        backref='product',
        lazy=True,
        cascade='all, delete-orphan'
    )

class ProductStatusHistory(db.Model):
    __tablename__ = 'product_status_history'

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    status_name = db.Column(db.String(50), nullable=False)
    changed_at = db.Column(db.DateTime, nullable=False, default=now_vladivostok)

class Buyer(db.Model):
    __tablename__ = 'buyers'

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(255), nullable=False)
    address = db.Column(db.Text, nullable=True)
    contact_info = db.Column(db.String(100), nullable=False)
    source_channel = db.Column(db.String(100), nullable=True)
    notes = db.Column(db.Text, nullable=True)

    sales = db.relationship('Sale', backref='buyer', lazy=True)

class Sale(db.Model):
    __tablename__ = 'sales'

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    buyer_id = db.Column(db.Integer, db.ForeignKey('buyers.id'), nullable=False)
    sale_state = db.Column(db.String(50), nullable=False)
    sale_begin_date = db.Column(db.DateTime, nullable=False, default=now_vladivostok)
    sale_date = db.Column(db.DateTime, nullable=True)
    channel = db.Column(db.String(100), nullable=True)
    sale_comment = db.Column(db.Text, nullable=True)
    invoice_scan_path = db.Column(db.Text, nullable=True)
    payment_receipt_scan_path = db.Column(db.Text, nullable=True)

    product = db.relationship('Product', backref=db.backref('sales', lazy=True))

class FinType(db.Model):
    __tablename__ = 'fin_type'

    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(10), nullable=False)

    finances = db.relationship('Finance', backref='fin_type', lazy=True)

class Article(db.Model):
    __tablename__ = 'article'

    id = db.Column(db.Integer, primary_key=True)
    article = db.Column(db.String(20), nullable=False)

    finances = db.relationship('Finance', backref='article_ref', lazy=True)

class Finance(db.Model):
    __tablename__ = 'finances'

    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.Integer, db.ForeignKey('fin_type.id'), nullable=False)
    op_date = db.Column(db.DateTime, nullable=False, default=now_vladivostok)
    article = db.Column(db.Integer, db.ForeignKey('article.id'), nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=True)
    sale_id = db.Column(db.Integer, db.ForeignKey('sales.id'), nullable=True)
    comment = db.Column(db.Text, nullable=True)

    product = db.relationship('Product', backref='finances')
    sale = db.relationship('Sale', backref='finances')

AVAILABLE_SALE_STATES = [
    'Активна',
    'Завершена',
    'Отменена'
]

AVAILABLE_STATUSES = [
    'Требует ремонта',
    'В ремонте',
    'Готов к продаже',
    'Зарезервирован',
    'Продан',
    'Снят с продажи'
]

WAREHOUSE_UNIQUE_STATUSES = {
    'Требует ремонта',
    'В ремонте',
    'Готов к продаже',
    'Опубликован',
    'Зарезервирован'
}

WAREHOUSE_LOCKED_STATUSES = {
    'Продан',
    'Снят с продажи'
}

class Advertisement(db.Model):
    __tablename__ = 'advertisements'

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    platform = db.Column(db.String(100), nullable=False)
    ad_price = db.Column(db.Numeric(10, 2), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=False)
    media_urls = db.Column(db.Text, nullable=True)
    ad_status = db.Column(db.String(50), nullable=False)
    ad_url = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=now_vladivostok)

    product = db.relationship('Product', backref='advertisements')

AVAILABLE_AD_PLATFORMS = [
    'Avito',
    'Telegram',
    'Другое'
]

AVAILABLE_AD_STATUSES = [
    'Активно',
    'Снято',
    'Продано'
]

def ensure_upload_folder():
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def get_free_warehouse_slot():
    occupied_slots = {
        product.warehouse_id
        for product in Product.query.filter(Product.current_status.in_(list(WAREHOUSE_UNIQUE_STATUSES))).all()
        if product.warehouse_id
    }

    for number in range(1, 500):
        slot = f'{number:03d}'
        if slot not in occupied_slots:
            return slot

    return None

def is_valid_warehouse_id(value):
    return bool(re.fullmatch(r'\d{3}', value or ''))

def save_uploaded_image(file_storage):
    if not file_storage or not file_storage.filename:
        return None

    filename = secure_filename(file_storage.filename)
    if not filename:
        return None

    ext = os.path.splitext(filename)[1].lower()
    allowed_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.webp'}

    if ext not in allowed_extensions:
        return None

    unique_filename = f'{uuid.uuid4().hex}{ext}'
    full_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
    file_storage.save(full_path)

    return f'uploads/{unique_filename}'

def save_uploaded_scan(file_storage):
    return save_uploaded_image(file_storage)

def warehouse_slot_is_busy(warehouse_id, current_status, exclude_product_id=None):
    if current_status not in WAREHOUSE_UNIQUE_STATUSES:
        return False

    query = Product.query.filter(
        Product.warehouse_id == warehouse_id,
        Product.current_status.in_(list(WAREHOUSE_UNIQUE_STATUSES))
    )

    if exclude_product_id is not None:
        query = query.filter(Product.id != exclude_product_id)

    return db.session.query(query.exists()).scalar()

def get_total_product_expenses(product):
    total_expenses = 0.0
    has_out_finances = False

    for fin in product.finances:
        if fin.fin_type and fin.fin_type.type == 'OUT' and fin.amount is not None:
            total_expenses += float(fin.amount)
            has_out_finances = True

    if not has_out_finances and product.purchase_price is not None:
        total_expenses += float(product.purchase_price)

    return total_expenses

def build_buyer_form_data(request_form):
    return {
        'full_name': request_form.get('buyer_full_name', '').strip(),
        'address': request_form.get('buyer_address', '').strip(),
        'contact_info': request_form.get('buyer_contact_info', '').strip(),
        'notes': request_form.get('buyer_notes', '').strip(),
    }

def build_sale_form_data(request_form, channel=''):
    return {
        'buyer_id': request_form.get('buyer_id', '').strip(),
        'buyer_search': request_form.get('buyer_search', '').strip(),
        'channel': channel,
        'sale_comment': request_form.get('sale_comment', '').strip(),
    }

def get_preferred_advertisement_for_product(product_id):
    active_ad = (
        Advertisement.query
        .filter_by(product_id=product_id, ad_status='Активно')
        .order_by(Advertisement.created_at.desc())
        .first()
    )
    if active_ad:
        return active_ad

    return (
        Advertisement.query
        .filter_by(product_id=product_id)
        .order_by(Advertisement.created_at.desc())
        .first()
    )

def get_sale_channel_for_product(product_id):
    ad = get_preferred_advertisement_for_product(product_id)
    if ad and ad.platform:
        return ad.platform

    return ''

def get_sale_amount_value(sale):
    income_finance = next(
        (
            finance for finance in sale.finances
            if finance.fin_type and finance.fin_type.type == 'IN' and finance.amount is not None
        ),
        None
    )
    if income_finance:
        return float(income_finance.amount)

    ad = get_preferred_advertisement_for_product(sale.product_id)
    if ad and ad.ad_price is not None:
        return float(ad.ad_price)

    return 0.0

def get_current_sale_for_product(product):
    active_sale = (
        Sale.query
        .filter_by(product_id=product.id, sale_state='Активна')
        .order_by(Sale.sale_begin_date.desc())
        .first()
    )
    if active_sale:
        return active_sale

    return (
        Sale.query
        .filter_by(product_id=product.id)
        .order_by(Sale.sale_begin_date.desc(), Sale.id.desc())
        .first()
    )

def build_buyer_sales_rows(sales):
    buyer_sales_map = {}

    for sale in sales:
        if sale.sale_state != 'Завершена':
            continue

        buyer_id = sale.buyer.id
        buyer_sales_map.setdefault(buyer_id, {
            'buyer': sale.buyer,
            'count': 0,
            'amount': 0.0
        })
        buyer_sales_map[buyer_id]['count'] += 1
        buyer_sales_map[buyer_id]['amount'] += get_sale_amount_value(sale)

    return list(buyer_sales_map.values())

def add_product_status_history_if_changed(product, new_status):
    old_status = product.current_status
    if old_status != new_status:
        product.current_status = new_status
        db.session.add(ProductStatusHistory(
            product_id=product.id,
            status_name=new_status
        ))

def set_active_ads_to_removed(product_id):
    active_ads = Advertisement.query.filter_by(product_id=product_id, ad_status='Активно').all()
    for ad in active_ads:
        ad.ad_status = 'Снято'

def set_all_ads_to_sold(product_id):
    ads = Advertisement.query.filter(Advertisement.product_id == product_id).all()
    for ad in ads:
        ad.ad_status = 'Продано'

def restore_advertisement_after_sale_cancel(product_id):
    active_ad = Advertisement.query.filter_by(product_id=product_id, ad_status='Активно').first()
    if active_ad:
        return active_ad

    removed_ad = (
        Advertisement.query
        .filter_by(product_id=product_id, ad_status='Снято')
        .order_by(Advertisement.created_at.desc())
        .first()
    )
    if removed_ad:
        removed_ad.ad_status = 'Активно'
        return removed_ad

    return None

def sync_product_publication_status(product):
    has_active_ads = (
        Advertisement.query
        .filter_by(product_id=product.id, ad_status='Активно')
        .first()
        is not None
    )

    if has_active_ads and product.current_status == 'Готов к продаже':
        add_product_status_history_if_changed(product, 'Опубликован')
    elif not has_active_ads and product.current_status == 'Опубликован':
        add_product_status_history_if_changed(product, 'Готов к продаже')

def create_default_fin_types():
    default_types = ['IN', 'OUT']

    for item in default_types:
        exists = FinType.query.filter_by(type=item).first()
        if not exists:
            db.session.add(FinType(type=item))

    db.session.commit()

def build_finance_form_data(request_form):
    return {
        'type': request_form.get('type', '').strip(),
        'op_date': request_form.get('op_date', '').strip(),
        'article': request_form.get('article', '').strip(),
        'amount': request_form.get('amount', '').strip(),
        'product_id': request_form.get('product_id', '').strip(),
        'sale_id': request_form.get('sale_id', '').strip(),
        'comment': request_form.get('comment', '').strip(),
    }
    
def create_default_articles():
    default_articles = [
        'закупка',
        'ремонт',
        'комиссия',
        'продажа',
        'доставка',
        'прочее'
    ]

    for item in default_articles:
        exists = Article.query.filter_by(article=item).first()
        if not exists:
            db.session.add(Article(article=item))

    db.session.commit()

def build_reports_data(request_args):
    date_from = request_args.get('date_from', '').strip()
    date_to = request_args.get('date_to', '').strip()
    product_status = request_args.get('product_status', '').strip()
    category_id = request_args.get('category_id', '').strip()

    show_products = request_args.get('show_products') == '1'
    show_sold_products = request_args.get('show_sold_products') == '1'
    show_sales = request_args.get('show_sales') == '1'
    show_finances = request_args.get('show_finances') == '1'
    show_expense_articles = request_args.get('show_expense_articles') == '1'
    show_sales_channels = request_args.get('show_sales_channels') == '1'
    show_buyers_analytics = request_args.get('show_buyers_analytics') == '1'
    show_profit = request_args.get('show_profit') == '1'
    buyer_sales_sort = request_args.get('buyer_sales_sort', 'amount_desc').strip()

    date_from_value = None
    date_to_value = None

    try:
        if date_from:
            date_from_value = datetime.strptime(date_from, '%Y-%m-%d')
        if date_to:
            date_to_value = datetime.strptime(date_to, '%Y-%m-%d').replace(hour=23, minute=59, second=59)
    except ValueError:
        pass

    products_query = Product.query.join(Category)
    sales_query = Sale.query.join(Product).join(Buyer)
    finances_query = Finance.query.join(FinType).join(Article)
    ads_query = Advertisement.query

    if product_status:
        products_query = products_query.filter(Product.current_status == product_status)

    if category_id:
        try:
            products_query = products_query.filter(Product.category_id == int(category_id))
        except ValueError:
            pass

    if date_from_value:
        sales_query = sales_query.filter(Sale.sale_begin_date >= date_from_value)
        finances_query = finances_query.filter(Finance.op_date >= date_from_value)
        ads_query = ads_query.filter(Advertisement.created_at >= date_from_value)

    if date_to_value:
        sales_query = sales_query.filter(Sale.sale_begin_date <= date_to_value)
        finances_query = finances_query.filter(Finance.op_date <= date_to_value)
        ads_query = ads_query.filter(Advertisement.created_at <= date_to_value)

    products = products_query.order_by(Product.id.desc()).all()
    sales = sales_query.order_by(Sale.sale_begin_date.desc()).all()
    finances = finances_query.order_by(Finance.op_date.desc()).all()
    advertisements = ads_query.order_by(Advertisement.created_at.desc()).all()

    income_total = 0.0
    expense_total = 0.0

    for item in finances:
        if item.fin_type.type == 'IN':
            income_total += float(item.amount)
        elif item.fin_type.type == 'OUT':
            expense_total += float(item.amount)

    active_ads_count = sum(1 for ad in advertisements if ad.ad_status == 'Активно')
    active_sales_count = sum(1 for sale in sales if sale.sale_state == 'Активна')
    completed_sales_count = sum(1 for sale in sales if sale.sale_state == 'Завершена')

    repair_count = Product.query.filter_by(current_status='В ремонте').count()
    reserved_count = Product.query.filter_by(current_status='Зарезервирован').count()
    sold_count = Product.query.filter_by(current_status='Продан').count()

    sold_products = [sale for sale in sales if sale.sale_state == 'Завершена']

    product_profit_rows = []
    for product in products:
        expense_sum = 0.0
        income_sum = 0.0

        for fin in product.finances:
            if date_from_value and fin.op_date < date_from_value:
                continue
            if date_to_value and fin.op_date > date_to_value:
                continue

            if fin.fin_type.type == 'OUT':
                expense_sum += float(fin.amount)
            elif fin.fin_type.type == 'IN':
                income_sum += float(fin.amount)

        product_profit_rows.append({
            'product': product,
            'expense': expense_sum,
            'income': income_sum,
            'profit': income_sum - expense_sum
        })

    expense_by_article = {}
    for item in finances:
        if item.fin_type.type == 'OUT':
            article_name = item.article_ref.article
            expense_by_article.setdefault(article_name, 0.0)
            expense_by_article[article_name] += float(item.amount)

    expense_by_article_rows = [
        {'article': article, 'amount': amount}
        for article, amount in expense_by_article.items()
    ]
    expense_by_article_rows.sort(key=lambda x: x['amount'], reverse=True)

    sales_by_channel = {}
    for sale in sales:
        channel_name = sale.channel.strip() if sale.channel else 'Не указан'
        sales_by_channel.setdefault(channel_name, 0)
        sales_by_channel[channel_name] += 1

    sales_by_channel_rows = [
        {'channel': channel, 'count': count}
        for channel, count in sales_by_channel.items()
    ]
    sales_by_channel_rows.sort(key=lambda x: x['count'], reverse=True)

    buyer_sales_rows = build_buyer_sales_rows(sales)
    if buyer_sales_sort == 'amount_asc':
        buyer_sales_rows.sort(key=lambda x: x['amount'])
    elif buyer_sales_sort == 'count_desc':
        buyer_sales_rows.sort(key=lambda x: x['count'], reverse=True)
    elif buyer_sales_sort == 'count_asc':
        buyer_sales_rows.sort(key=lambda x: x['count'])
    elif buyer_sales_sort == 'buyer_asc':
        buyer_sales_rows.sort(key=lambda x: x['buyer'].full_name.lower())
    else:
        buyer_sales_rows.sort(key=lambda x: x['amount'], reverse=True)

    summary = {
        'products_count': len(products),
        'active_ads_count': active_ads_count,
        'active_sales_count': active_sales_count,
        'completed_sales_count': completed_sales_count,
        'income_total': income_total,
        'expense_total': expense_total,
        'profit_total': income_total - expense_total,
        'repair_count': repair_count,
        'reserved_count': reserved_count,
        'sold_count': sold_count
    }

    filters = {
        'date_from': date_from,
        'date_to': date_to,
        'product_status': product_status,
        'category_id': category_id,
        'show_products': show_products,
        'show_sold_products': show_sold_products,
        'show_sales': show_sales,
        'show_finances': show_finances,
        'show_expense_articles': show_expense_articles,
        'show_sales_channels': show_sales_channels,
        'show_buyers_analytics': show_buyers_analytics,
        'buyer_sales_sort': buyer_sales_sort,
        'show_profit': show_profit
    }

    return {
        'summary': summary,
        'products': products,
        'sales': sales,
        'finances': finances,
        'sold_products': sold_products,
        'product_profit_rows': product_profit_rows,
        'expense_by_article_rows': expense_by_article_rows,
        'sales_by_channel_rows': sales_by_channel_rows,
        'buyer_sales_rows': buyer_sales_rows,
        'filters': filters
    }

@app.route('/')
def home():
    if session.get('role') in ['ip', 'admin']:
        return redirect(url_for('products'))
    return redirect(url_for('login'))

@app.route('/admin')
def admin_dashboard():
    return redirect(url_for('products'))

app.route('/ip')
def ip_dashboard():
    return redirect(url_for('products'))
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username, password=password).first()

        if user:
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            return redirect(url_for('products'))
        else:
            flash('Неверный логин или пароль', 'danger')

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/products')
def products():
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    category_id = request.args.get('category_id', '').strip()
    manufacturer = request.args.get('manufacturer', '').strip()
    status = request.args.get('status', '').strip()
    price_from = request.args.get('price_from', '').strip()
    price_to = request.args.get('price_to', '').strip()
    search = request.args.get('search', '').strip()
    sort_by = request.args.get('sort_by', 'id_desc').strip()

    query = Product.query.join(Category)

    if category_id:
        query = query.filter(Product.category_id == int(category_id))

    if manufacturer:
        query = query.filter(Product.manufacturer.ilike(f'%{manufacturer}%'))

    if status:
        query = query.filter(Product.current_status == status)
    else:
        query = query.filter(Product.current_status != 'Продан')

    if search:
        query = query.filter(
            db.or_(
                Product.manufacturer.ilike(f'%{search}%'),
                Product.model.ilike(f'%{search}%'),
                Product.warehouse_id.ilike(f'%{search}%'),
                Product.comments.ilike(f'%{search}%'),
                Product.specifications.ilike(f'%{search}%')
            )
        )

    if price_from:
        try:
            query = query.filter(Product.purchase_price >= float(price_from))
        except ValueError:
            flash('Минимальная цена указана некорректно', 'danger')

    if price_to:
        try:
            query = query.filter(Product.purchase_price <= float(price_to))
        except ValueError:
            flash('Максимальная цена указана некорректно', 'danger')

    if sort_by == 'id_asc':
        query = query.order_by(Product.id.asc())
    elif sort_by == 'id_desc':
        query = query.order_by(Product.id.desc())
    elif sort_by == 'price_asc':
        query = query.order_by(Product.purchase_price.asc())
    elif sort_by == 'price_desc':
        query = query.order_by(Product.purchase_price.desc())
    else:
        query = query.order_by(Product.id.desc())

    product_list = query.all()
    categories = Category.query.order_by(Category.name).all()

    manufacturers = [
        row[0] for row in db.session.query(Product.manufacturer)
        .filter(Product.manufacturer.isnot(None))
        .distinct()
        .order_by(Product.manufacturer.asc())
        .all()
        if row[0]
    ]

    filters = {
        'category_id': category_id,
        'manufacturer': manufacturer,
        'status': status,
        'price_from': price_from,
        'price_to': price_to,
        'search': search,
        'sort_by': sort_by
    }

    return render_template(
        'products.html',
        products=product_list,
        categories=categories,
        manufacturers=manufacturers,
        statuses=AVAILABLE_STATUSES,
        filters=filters
    )

@app.route('/products/create', methods=['GET', 'POST'])
def create_product():
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    categories = Category.query.order_by(Category.name).all()
    suggested_slot = get_free_warehouse_slot()

    if request.method == 'POST':
        form_data = build_product_form_data(request.form)

        category_id = form_data['category_id']
        warehouse_id = form_data['warehouse_id']
        manufacturer = form_data['manufacturer']
        model = form_data['model']
        purchase_price = form_data['purchase_price']
        specifications = form_data['specifications']
        condition_rate = form_data['condition_rate']
        current_status = form_data['current_status']
        comments = form_data['comments']
        image_file = request.files.get('image_file')

        if not category_id or not manufacturer or not model or not condition_rate or not current_status:
            flash('Заполните все обязательные поля', 'danger')
            return render_template(
                'product_form.html',
                product=form_data,
                categories=categories,
                statuses=AVAILABLE_STATUSES,
                suggested_slot=suggested_slot,
                warehouse_locked=False,
                is_edit=False
            )

        if not warehouse_id:
            warehouse_id = suggested_slot or ''
            form_data['warehouse_id'] = warehouse_id

        if not warehouse_id:
            flash('Свободные складские места закончились', 'danger')
            return render_template(
                'product_form.html',
                product=form_data,
                categories=categories,
                statuses=AVAILABLE_STATUSES,
                suggested_slot=suggested_slot,
                warehouse_locked=False,
                is_edit=False
            )

        if not is_valid_warehouse_id(warehouse_id):
            flash('Складской номер должен состоять ровно из 3 цифр', 'danger')
            return render_template(
                'product_form.html',
                product=form_data,
                categories=categories,
                statuses=AVAILABLE_STATUSES,
                suggested_slot=suggested_slot,
                warehouse_locked=False,
                is_edit=False
            )

        try:
            condition_rate_int = int(condition_rate)
            if condition_rate_int < 1 or condition_rate_int > 5:
                flash('Оценка состояния должна быть от 1 до 5', 'danger')
                return render_template(
                    'product_form.html',
                    product=form_data,
                    categories=categories,
                    statuses=AVAILABLE_STATUSES,
                    suggested_slot=suggested_slot,
                    warehouse_locked=False,
                    is_edit=False
                )

            purchase_price_value = None
            if purchase_price:
                purchase_price_value = float(purchase_price)
                if purchase_price_value <= 0:
                    flash('Закупочная цена должна быть больше 0', 'danger')
                    return render_template(
                        'product_form.html',
                        product=form_data,
                        categories=categories,
                        statuses=AVAILABLE_STATUSES,
                        suggested_slot=suggested_slot,
                        warehouse_locked=False,
                        is_edit=False
                    )

            if warehouse_slot_is_busy(warehouse_id, current_status):
                flash('Это складское место уже занято другим активным товаром', 'danger')
                return render_template(
                    'product_form.html',
                    product=form_data,
                    categories=categories,
                    statuses=AVAILABLE_STATUSES,
                    suggested_slot=suggested_slot,
                    warehouse_locked=False,
                    is_edit=False
                )

            image_path = None
            if image_file and image_file.filename:
                image_path = save_uploaded_image(image_file)
                if image_path is None:
                    flash('Допустимы только изображения JPG, JPEG, PNG, GIF, WEBP', 'danger')
                    return render_template(
                        'product_form.html',
                        product=form_data,
                        categories=categories,
                        statuses=AVAILABLE_STATUSES,
                        suggested_slot=suggested_slot,
                        warehouse_locked=False,
                        is_edit=False
                    )

            new_product = Product(
                category_id=int(category_id),
                warehouse_id=warehouse_id,
                manufacturer=manufacturer,
                model=model,
                purchase_price=purchase_price_value,
                image_path=image_path,
                specifications=specifications if specifications else None,
                condition_rate=condition_rate_int,
                current_status=current_status,
                comments=comments if comments else None
            )

            db.session.add(new_product)
            db.session.flush()

            db.session.add(ProductStatusHistory(
                product_id=new_product.id,
                status_name=current_status
            ))

            if purchase_price_value is not None:
                out_type_id = get_fin_type_id_by_code('OUT')
                purchase_article_id = get_article_id_by_name('закупка')

                if out_type_id and purchase_article_id:
                    db.session.add(Finance(
                        type=out_type_id,
                        op_date=now_vladivostok(),
                        article=purchase_article_id,
                        amount=purchase_price_value,
                        product_id=new_product.id,
                        sale_id=None,
                        comment='Автоматически создано при регистрации товара'
                    ))

            db.session.commit()
            flash('Карточка товара успешно создана', 'success')
            return redirect(url_for('products'))

        except ValueError:
            flash('Проверьте корректность числовых полей', 'danger')
            return render_template(
                'product_form.html',
                product=form_data,
                categories=categories,
                statuses=AVAILABLE_STATUSES,
                suggested_slot=suggested_slot,
                warehouse_locked=False,
                is_edit=False
            )

    empty_form_data = {
        'category_id': '',
        'warehouse_id': suggested_slot or '',
        'manufacturer': '',
        'model': '',
        'purchase_price': '',
        'image_path': None,
        'specifications': '',
        'condition_rate': '',
        'current_status': '',
        'comments': '',
    }

    return render_template(
        'product_form.html',
        product=empty_form_data,
        categories=categories,
        statuses=AVAILABLE_STATUSES,
        suggested_slot=suggested_slot,
        warehouse_locked=False,
        is_edit=False
    )
    
@app.route('/products/<int:product_id>/edit', methods=['GET', 'POST'])
def edit_product(product_id):
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    db_product = Product.query.get_or_404(product_id)
    categories = Category.query.order_by(Category.name).all()
    warehouse_locked = db_product.current_status in WAREHOUSE_LOCKED_STATUSES

    show_repair_expense_form = request.args.get('show_repair_expense') == '1'

    if request.method == 'POST':
        action = request.form.get('action', 'save_product')

        if action == 'save_repair_expense':
            repair_amount = request.form.get('repair_amount', '').strip()
            repair_comment = request.form.get('repair_comment', '').strip()

            product_data = {
                'id': db_product.id,
                'category_id': db_product.category_id,
                'warehouse_id': db_product.warehouse_id or '',
                'manufacturer': db_product.manufacturer or '',
                'model': db_product.model or '',
                'purchase_price': str(db_product.purchase_price) if db_product.purchase_price is not None else '',
                'image_path': db_product.image_path,
                'specifications': db_product.specifications or '',
                'condition_rate': db_product.condition_rate,
                'current_status': db_product.current_status or '',
                'comments': db_product.comments or '',
                'status_history': db_product.status_history
            }

            try:
                repair_amount_value = float(repair_amount)
                if repair_amount_value <= 0:
                    flash('Сумма расхода на ремонт должна быть больше 0', 'danger')
                    return render_template(
                        'product_form.html',
                        product=product_data,
                        categories=categories,
                        statuses=AVAILABLE_STATUSES,
                        suggested_slot=None,
                        warehouse_locked=warehouse_locked,
                        is_edit=True,
                        show_repair_expense_form=True,
                        repair_form={
                            'repair_amount': repair_amount,
                            'repair_comment': repair_comment
                        }
                    )

                out_type_id = get_fin_type_id_by_code('OUT')
                repair_article_id = get_article_id_by_name('ремонт')

                if not out_type_id or not repair_article_id:
                    flash('Не найдены справочники финансовой операции для ремонта', 'danger')
                    return render_template(
                        'product_form.html',
                        product=product_data,
                        categories=categories,
                        statuses=AVAILABLE_STATUSES,
                        suggested_slot=None,
                        warehouse_locked=warehouse_locked,
                        is_edit=True,
                        show_repair_expense_form=True,
                        repair_form={
                            'repair_amount': repair_amount,
                            'repair_comment': repair_comment
                        }
                    )

                db.session.add(Finance(
                    type=out_type_id,
                    op_date=now_vladivostok(),
                    article=repair_article_id,
                    amount=repair_amount_value,
                    product_id=db_product.id,
                    sale_id=None,
                    comment=repair_comment or 'Расход на ремонт товара'
                ))
                db.session.commit()

                flash('Расход на ремонт успешно добавлен', 'success')
                return redirect(url_for('edit_product', product_id=db_product.id))

            except ValueError:
                flash('Проверьте корректность суммы расхода на ремонт', 'danger')
                return render_template(
                    'product_form.html',
                    product=product_data,
                    categories=categories,
                    statuses=AVAILABLE_STATUSES,
                    suggested_slot=None,
                    warehouse_locked=warehouse_locked,
                    is_edit=True,
                    show_repair_expense_form=True,
                    repair_form={
                        'repair_amount': repair_amount,
                        'repair_comment': repair_comment
                    }
                )

        form_data = build_product_form_data(request.form, image_path=db_product.image_path)

        old_status = db_product.current_status
        old_warehouse_id = db_product.warehouse_id

        category_id = form_data['category_id']
        manufacturer = form_data['manufacturer']
        model = form_data['model']
        purchase_price = form_data['purchase_price']
        specifications = form_data['specifications']
        condition_rate = form_data['condition_rate']
        current_status = form_data['current_status']
        comments = form_data['comments']
        image_file = request.files.get('image_file')

        if warehouse_locked:
            warehouse_id = old_warehouse_id
            form_data['warehouse_id'] = old_warehouse_id or ''
        else:
            warehouse_id = form_data['warehouse_id']

        if not category_id or not manufacturer or not model or not condition_rate or not current_status:
            flash('Заполните все обязательные поля', 'danger')
            return render_template(
                'product_form.html',
                product=form_data,
                categories=categories,
                statuses=AVAILABLE_STATUSES,
                suggested_slot=None,
                warehouse_locked=warehouse_locked,
                is_edit=True,
                show_repair_expense_form=False,
                repair_form={'repair_amount': '', 'repair_comment': ''}
            )

        if not warehouse_id:
            flash('Укажите складской номер', 'danger')
            return render_template(
                'product_form.html',
                product=form_data,
                categories=categories,
                statuses=AVAILABLE_STATUSES,
                suggested_slot=None,
                warehouse_locked=warehouse_locked,
                is_edit=True,
                show_repair_expense_form=False,
                repair_form={'repair_amount': '', 'repair_comment': ''}
            )

        if not is_valid_warehouse_id(warehouse_id):
            flash('Складской номер должен состоять ровно из 3 цифр', 'danger')
            return render_template(
                'product_form.html',
                product=form_data,
                categories=categories,
                statuses=AVAILABLE_STATUSES,
                suggested_slot=None,
                warehouse_locked=warehouse_locked,
                is_edit=True,
                show_repair_expense_form=False,
                repair_form={'repair_amount': '', 'repair_comment': ''}
            )

        try:
            condition_rate_int = int(condition_rate)
            if condition_rate_int < 1 or condition_rate_int > 5:
                flash('Оценка состояния должна быть от 1 до 5', 'danger')
                return render_template(
                    'product_form.html',
                    product=form_data,
                    categories=categories,
                    statuses=AVAILABLE_STATUSES,
                    suggested_slot=None,
                    warehouse_locked=warehouse_locked,
                    is_edit=True,
                    show_repair_expense_form=False,
                    repair_form={'repair_amount': '', 'repair_comment': ''}
                )

            purchase_price_value = None
            if purchase_price:
                purchase_price_value = float(purchase_price)
                if purchase_price_value <= 0:
                    flash('Закупочная цена должна быть больше 0', 'danger')
                    return render_template(
                        'product_form.html',
                        product=form_data,
                        categories=categories,
                        statuses=AVAILABLE_STATUSES,
                        suggested_slot=None,
                        warehouse_locked=warehouse_locked,
                        is_edit=True,
                        show_repair_expense_form=False,
                        repair_form={'repair_amount': '', 'repair_comment': ''}
                    )

            if warehouse_slot_is_busy(warehouse_id, current_status, exclude_product_id=db_product.id):
                flash('Это складское место уже занято другим активным товаром', 'danger')
                return render_template(
                    'product_form.html',
                    product=form_data,
                    categories=categories,
                    statuses=AVAILABLE_STATUSES,
                    suggested_slot=None,
                    warehouse_locked=warehouse_locked,
                    is_edit=True,
                    show_repair_expense_form=False,
                    repair_form={'repair_amount': '', 'repair_comment': ''}
                )

            if image_file and image_file.filename:
                new_image_path = save_uploaded_image(image_file)
                if new_image_path is None:
                    flash('Допустимы только изображения JPG, JPEG, PNG, GIF, WEBP', 'danger')
                    return render_template(
                        'product_form.html',
                        product=form_data,
                        categories=categories,
                        statuses=AVAILABLE_STATUSES,
                        suggested_slot=None,
                        warehouse_locked=warehouse_locked,
                        is_edit=True,
                        show_repair_expense_form=False,
                        repair_form={'repair_amount': '', 'repair_comment': ''}
                    )
                db_product.image_path = new_image_path
                form_data['image_path'] = new_image_path

            db_product.category_id = int(category_id)
            db_product.warehouse_id = warehouse_id
            db_product.manufacturer = manufacturer
            db_product.model = model
            db_product.purchase_price = purchase_price_value
            db_product.specifications = specifications if specifications else None
            db_product.condition_rate = condition_rate_int
            db_product.current_status = current_status
            db_product.comments = comments if comments else None

            if old_status != current_status:
                db.session.add(ProductStatusHistory(
                    product_id=db_product.id,
                    status_name=current_status
                ))

            db.session.commit()

            if old_status == 'В ремонте' and current_status != 'В ремонте':
                flash('Карточка товара сохранена. Укажите расход на ремонт ниже.', 'success')
                return redirect(url_for('edit_product', product_id=db_product.id, show_repair_expense=1))

            flash('Карточка товара успешно обновлена', 'success')
            return redirect(url_for('edit_product', product_id=db_product.id))

        except ValueError:
            flash('Проверьте корректность числовых полей', 'danger')
            return render_template(
                'product_form.html',
                product=form_data,
                categories=categories,
                statuses=AVAILABLE_STATUSES,
                suggested_slot=None,
                warehouse_locked=warehouse_locked,
                is_edit=True,
                show_repair_expense_form=False,
                repair_form={'repair_amount': '', 'repair_comment': ''}
            )

    product_data = {
        'id': db_product.id,
        'category_id': db_product.category_id,
        'warehouse_id': db_product.warehouse_id or '',
        'manufacturer': db_product.manufacturer or '',
        'model': db_product.model or '',
        'purchase_price': str(db_product.purchase_price) if db_product.purchase_price is not None else '',
        'image_path': db_product.image_path,
        'specifications': db_product.specifications or '',
        'condition_rate': db_product.condition_rate,
        'current_status': db_product.current_status or '',
        'comments': db_product.comments or '',
        'status_history': db_product.status_history
    }

    return render_template(
        'product_form.html',
        product=product_data,
        categories=categories,
        statuses=AVAILABLE_STATUSES,
        suggested_slot=None,
        warehouse_locked=warehouse_locked,
        is_edit=True,
        show_repair_expense_form=show_repair_expense_form,
        repair_form={'repair_amount': '', 'repair_comment': ''}
    )    
    
@app.route('/advertisements')
def advertisements():
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    platform = request.args.get('platform', '').strip()
    ad_status = request.args.get('ad_status', 'Активно').strip()
    manufacturer = request.args.get('manufacturer', '').strip()
    category_id = request.args.get('category_id', '').strip()
    price_from = request.args.get('price_from', '').strip()
    price_to = request.args.get('price_to', '').strip()
    sort_by = request.args.get('sort_by', 'created_desc').strip()

    query = Advertisement.query.join(Product).join(Category)

    if platform:
        query = query.filter(Advertisement.platform == platform)

    if ad_status:
        query = query.filter(Advertisement.ad_status == ad_status)

    if manufacturer:
        query = query.filter(Product.manufacturer == manufacturer)

    if category_id:
        try:
            query = query.filter(Product.category_id == int(category_id))
        except ValueError:
            flash('Категория указана некорректно', 'danger')

    if price_from:
        try:
            query = query.filter(Advertisement.ad_price >= float(price_from))
        except ValueError:
            flash('Минимальная цена указана некорректно', 'danger')

    if price_to:
        try:
            query = query.filter(Advertisement.ad_price <= float(price_to))
        except ValueError:
            flash('Максимальная цена указана некорректно', 'danger')

    if sort_by == 'created_asc':
        query = query.order_by(Advertisement.created_at.asc())
    elif sort_by == 'created_desc':
        query = query.order_by(Advertisement.created_at.desc())
    elif sort_by == 'price_asc':
        query = query.order_by(Advertisement.ad_price.asc())
    elif sort_by == 'price_desc':
        query = query.order_by(Advertisement.ad_price.desc())
    elif sort_by == 'id_asc':
        query = query.order_by(Advertisement.id.asc())
    else:
        query = query.order_by(Advertisement.id.desc())

    ad_list = query.all()

    categories = Category.query.order_by(Category.name).all()

    manufacturers = [
        row[0] for row in db.session.query(Product.manufacturer)
        .filter(Product.manufacturer.isnot(None))
        .distinct()
        .order_by(Product.manufacturer.asc())
        .all()
        if row[0]
    ]

    filters = {
        'platform': platform,
        'ad_status': ad_status,
        'manufacturer': manufacturer,
        'category_id': category_id,
        'price_from': price_from,
        'price_to': price_to,
        'sort_by': sort_by
    }

    return render_template(
        'advertisements.html',
        advertisements=ad_list,
        platforms=AVAILABLE_AD_PLATFORMS,
        ad_statuses=AVAILABLE_AD_STATUSES,
        categories=categories,
        manufacturers=manufacturers,
        filters=filters
    )   
    
@app.route('/products/<int:product_id>/advertisements/create', methods=['GET', 'POST'])
def create_advertisement(product_id):
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    product = Product.query.get_or_404(product_id)

    if product.current_status != 'Готов к продаже':
        flash('Создание объявления доступно только для товаров со статусом «Готов к продаже»', 'danger')
        return redirect(url_for('edit_product', product_id=product.id))

    if request.method == 'POST':
        form_data = build_advertisement_form_data(request.form, product)

        platform = form_data['platform']
        ad_price = form_data['ad_price']
        title = form_data['title']
        description = form_data['description']
        media_urls = form_data['media_urls']
        ad_status = form_data['ad_status']
        ad_url = form_data['ad_url']

        if not platform or not ad_price or not title or not description or not ad_status:
            flash('Заполните все обязательные поля объявления', 'danger')
            return render_template(
                'advertisement_form.html',
                **build_advertisement_form_context(product, form_data)
            )

        try:
            ad_price_value = float(ad_price)
            if ad_price_value <= 0:
                flash('Цена в объявлении должна быть больше 0', 'danger')
                return render_template(
                    'advertisement_form.html',
                    **build_advertisement_form_context(product, form_data)
                )

            total_expenses = get_total_product_expenses(product)
            if ad_price_value < total_expenses:
                flash(
                    f'Цена в объявлении не может быть меньше суммы затрат по товару ({total_expenses:.2f} ₽)',
                    'danger'
                )
                return render_template(
                    'advertisement_form.html',
                    **build_advertisement_form_context(product, form_data)
                )

            new_advertisement = Advertisement(
                product_id=product.id,
                platform=platform,
                ad_price=ad_price_value,
                title=title,
                description=description,
                media_urls=media_urls if media_urls else None,
                ad_status=ad_status,
                ad_url=ad_url if ad_url else None
            )

            db.session.add(new_advertisement)
            sync_product_publication_status(product)

            db.session.commit()

            flash('Объявление успешно создано', 'success')
            return redirect(url_for('advertisements'))

        except ValueError:
            flash('Проверьте корректность цены объявления', 'danger')
            return render_template(
                'advertisement_form.html',
                **build_advertisement_form_context(product, form_data)
            )

    default_title = f'{product.manufacturer} {product.model}'.strip()

    description_parts = []
    if product.specifications:
        description_parts.append(product.specifications)
    if product.comments:
        description_parts.append(f'Комментарий: {product.comments}')

    default_description = '\n\n'.join(description_parts).strip()

    advertisement_data = {
        'platform': '',
        'ad_price': '',
        'title': default_title,
        'description': default_description,
        'media_urls': product.image_path if product.image_path else '',
        'ad_status': 'Активно',
        'ad_url': ''
    }

    return render_template(
        'advertisement_form.html',
        **build_advertisement_form_context(product, advertisement_data)
    )

@app.route('/advertisements/<int:advertisement_id>/edit', methods=['GET', 'POST'])
def edit_advertisement(advertisement_id):
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    db_advertisement = Advertisement.query.get_or_404(advertisement_id)
    product = db_advertisement.product

    if request.method == 'POST':
        form_data = build_advertisement_form_data(request.form, product)
        status_locked = db_advertisement.ad_status == 'Продано'

        platform = form_data['platform']
        ad_price = form_data['ad_price']
        title = form_data['title']
        description = form_data['description']
        media_urls = form_data['media_urls']
        ad_status = form_data['ad_status']
        ad_url = form_data['ad_url']

        if status_locked:
            if ad_status and ad_status != 'Продано':
                flash('Статус объявления «Продано» уже зафиксирован и не может быть изменен', 'danger')
                form_data['ad_status'] = 'Продано'
                return render_template(
                    'advertisement_form.html',
                    **build_advertisement_form_context(
                        product,
                        form_data,
                        is_edit=True,
                        advertisement_record=db_advertisement
                    )
                )

            form_data['ad_status'] = 'Продано'
            ad_status = 'Продано'

        if not platform or not ad_price or not title or not description or not ad_status:
            flash('Заполните все обязательные поля объявления', 'danger')
            return render_template(
                'advertisement_form.html',
                **build_advertisement_form_context(
                    product,
                    form_data,
                    is_edit=True,
                    advertisement_record=db_advertisement
                )
            )

        try:
            ad_price_value = float(ad_price)
            if ad_price_value <= 0:
                flash('Цена в объявлении должна быть больше 0', 'danger')
                return render_template(
                    'advertisement_form.html',
                    **build_advertisement_form_context(
                        product,
                        form_data,
                        is_edit=True,
                        advertisement_record=db_advertisement
                    )
                )

            total_expenses = get_total_product_expenses(product)
            if ad_price_value < total_expenses:
                flash(
                    f'Цена в объявлении не может быть меньше суммы затрат по товару ({total_expenses:.2f} ₽)',
                    'danger'
                )
                return render_template(
                    'advertisement_form.html',
                    **build_advertisement_form_context(
                        product,
                        form_data,
                        is_edit=True,
                        advertisement_record=db_advertisement
                    )
                )

            db_advertisement.platform = platform
            db_advertisement.ad_price = ad_price_value
            db_advertisement.title = title
            db_advertisement.description = description
            db_advertisement.media_urls = media_urls if media_urls else None
            db_advertisement.ad_status = ad_status
            db_advertisement.ad_url = ad_url if ad_url else None

            sync_product_publication_status(product)

            db.session.commit()

            flash('Карточка объявления успешно обновлена', 'success')
            return redirect(url_for('edit_advertisement', advertisement_id=db_advertisement.id))

        except ValueError:
            flash('Проверьте корректность цены объявления', 'danger')
            return render_template(
                'advertisement_form.html',
                **build_advertisement_form_context(
                    product,
                    form_data,
                    is_edit=True,
                    advertisement_record=db_advertisement
                )
            )

    return render_template(
        'advertisement_form.html',
        **build_advertisement_form_context(
            product,
            serialize_advertisement_form_data(db_advertisement),
            is_edit=True,
            advertisement_record=db_advertisement
        )
    )

@app.route('/advertisements/<int:advertisement_id>/remove', methods=['POST'])
def remove_advertisement(advertisement_id):
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    advertisement = Advertisement.query.get_or_404(advertisement_id)

    if advertisement.ad_status != 'Активно':
        flash('Снять с публикации можно только активное объявление', 'danger')
        return redirect(url_for('edit_advertisement', advertisement_id=advertisement.id))

    advertisement.ad_status = 'Снято'
    sync_product_publication_status(advertisement.product)
    db.session.commit()

    flash('Объявление снято с публикации. Можно создать новое объявление по этому товару.', 'success')
    return redirect(url_for('edit_advertisement', advertisement_id=advertisement.id))
    
@app.route('/buyers', methods=['GET', 'POST'])
def buyers():
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    search = request.args.get('search', '').strip()

    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        address = request.form.get('address', '').strip()
        contact_info = request.form.get('contact_info', '').strip()
        notes = request.form.get('notes', '').strip()

        if not full_name or not contact_info:
            flash('Для создания клиента заполните ФИО/никнейм и контактные данные', 'danger')
        else:
            normalized_phone = normalize_phone(contact_info)
            if not normalized_phone:
                flash('Введите телефон клиента в корректном формате', 'danger')
            else:
                new_buyer = Buyer(
                    full_name=full_name,
                    address=address or None,
                    contact_info=normalized_phone,
                    notes=notes or None
                )
                db.session.add(new_buyer)
                db.session.commit()
                flash('Клиент успешно добавлен', 'success')
                return redirect(url_for('buyers'))

    query = Buyer.query
    if search:
        query = query.filter(Buyer.contact_info.ilike(f'%{search}%'))

    buyer_list = query.order_by(Buyer.id.desc()).all()

    buyer_form = {
        'full_name': '',
        'address': '',
        'contact_info': '',
        'notes': ''
    }

    return render_template(
        'buyers.html',
        buyers=buyer_list,
        search=search,
        buyer_form=buyer_form
    )
    
@app.route('/products/<int:product_id>/sales/create', methods=['GET', 'POST'])
def create_sale(product_id):
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    product = Product.query.get_or_404(product_id)

    if product.current_status not in ['Готов к продаже', 'Опубликован']:
        flash('Создание сделки доступно только для товаров со статусом «Готов к продаже» или «Опубликован»', 'danger')
        return redirect(url_for('edit_product', product_id=product.id))

    existing_sale = (
        Sale.query
        .filter_by(product_id=product.id, sale_state='Активна')
        .order_by(Sale.sale_begin_date.desc())
        .first()
    )
    if existing_sale:
        flash('По этому товару уже существует активная сделка', 'danger')
        return redirect(url_for('sale_detail', sale_id=existing_sale.id))

    buyer_search = request.args.get('buyer_search', '').strip()
    sale_channel = get_sale_channel_for_product(product.id)
    sale_advertisement = get_preferred_advertisement_for_product(product.id)
    buyers_query = Buyer.query
    if buyer_search:
        buyers_query = buyers_query.filter(Buyer.contact_info.ilike(f'%{buyer_search}%'))
    buyer_list = buyers_query.order_by(Buyer.full_name.asc()).all()
    no_buyer_found = bool(buyer_search) and len(buyer_list) == 0

    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'create_buyer':
            buyer_data = build_buyer_form_data(request.form)

            if not buyer_data['full_name'] or not buyer_data['contact_info']:
                flash('Для создания покупателя заполните ФИО/никнейм и контактные данные', 'danger')
                sale_data = build_sale_form_data(request.form, sale_channel)
                return render_template(
                    'sale_form.html',
                    product=product,
                    buyers=buyer_list,
                    sale=sale_data,
                    buyer_form=buyer_data,
                    show_buyer_form=True,
                    no_buyer_found=no_buyer_found,
                    sale_advertisement=sale_advertisement
                )

            normalized_phone = normalize_phone(buyer_data['contact_info'])

            if not normalized_phone:
                flash('Введите телефон в корректном формате', 'danger')
                sale_data = build_sale_form_data(request.form, sale_channel)
                return render_template(
                    'sale_form.html',
                    product=product,
                    buyers=buyer_list,
                    sale=sale_data,
                    buyer_form=buyer_data,
                    show_buyer_form=True,
                    no_buyer_found=no_buyer_found,
                    sale_advertisement=sale_advertisement
                )

            new_buyer = Buyer(
                full_name=buyer_data['full_name'],
                address=buyer_data['address'] or None,
                contact_info=normalized_phone,
                notes=buyer_data['notes'] or None
            )
            
            db.session.add(new_buyer)
            db.session.commit()

            flash('Покупатель успешно создан. Теперь можно оформить сделку.', 'success')
            return redirect(url_for('create_sale', product_id=product.id, buyer_search=new_buyer.contact_info))

        sale_data = build_sale_form_data(request.form, sale_channel)

        if not sale_data['buyer_id']:
            flash('Выберите покупателя для сделки', 'danger')
            return render_template(
                'sale_form.html',
                product=product,
                buyers=buyer_list,
                sale=sale_data,
                buyer_form=build_buyer_form_data(request.form),
                show_buyer_form=request.form.get('show_buyer_form') == '1',
                no_buyer_found=no_buyer_found,
                sale_advertisement=sale_advertisement
            )

        buyer = Buyer.query.get(sale_data['buyer_id'])
        if not buyer:
            flash('Выбранный покупатель не найден', 'danger')
            return render_template(
                'sale_form.html',
                product=product,
                buyers=buyer_list,
                sale=sale_data,
                buyer_form=build_buyer_form_data(request.form),
                show_buyer_form=request.form.get('show_buyer_form') == '1',
                no_buyer_found=no_buyer_found,
                sale_advertisement=sale_advertisement
            )

        new_sale = Sale(
            product_id=product.id,
            buyer_id=buyer.id,
            sale_state='Активна',
            sale_begin_date=now_vladivostok(),
            channel=sale_channel or None,
            sale_comment=sale_data['sale_comment'] or None
        )

        db.session.add(new_sale)

        add_product_status_history_if_changed(product, 'Зарезервирован')

        db.session.commit()

        flash('Сделка успешно создана', 'success')
        return redirect(url_for('sale_detail', sale_id=new_sale.id))

    sale_data = {
        'buyer_id': '',
        'buyer_search': buyer_search,
        'channel': sale_channel,
        'sale_comment': ''
    }

    empty_buyer_form = {
        'full_name': '',
        'address': '',
        'contact_info': buyer_search,
        'notes': ''
    }

    return render_template(
        'sale_form.html',
        product=product,
        buyers=buyer_list,
        sale=sale_data,
        buyer_form=empty_buyer_form,
        show_buyer_form=False,
        no_buyer_found=no_buyer_found,
        sale_advertisement=sale_advertisement
    )

@app.route('/sales/<int:sale_id>')
def sale_detail(sale_id):
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    sale = Sale.query.get_or_404(sale_id)
    return render_template('sale_detail.html', sale=sale)

@app.route('/sales/<int:sale_id>/complete', methods=['POST'])
def complete_sale(sale_id):
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    sale = Sale.query.get_or_404(sale_id)

    if sale.sale_state != 'Активна':
        flash('Завершить можно только активную сделку', 'danger')
        return redirect(url_for('sale_detail', sale_id=sale.id))

    invoice_scan = request.files.get('invoice_scan')
    payment_receipt_scan = request.files.get('payment_receipt_scan')

    if not sale.invoice_scan_path and (not invoice_scan or not invoice_scan.filename):
        flash('Для завершения сделки загрузите скан накладной', 'danger')
        return redirect(url_for('sale_detail', sale_id=sale.id))

    if not sale.payment_receipt_scan_path and (not payment_receipt_scan or not payment_receipt_scan.filename):
        flash('Для завершения сделки загрузите скан чека об оплате', 'danger')
        return redirect(url_for('sale_detail', sale_id=sale.id))

    if invoice_scan and invoice_scan.filename:
        invoice_scan_path = save_uploaded_scan(invoice_scan)
        if invoice_scan_path is None:
            flash('Скан накладной должен быть изображением JPG, JPEG, PNG, GIF или WEBP', 'danger')
            return redirect(url_for('sale_detail', sale_id=sale.id))
        sale.invoice_scan_path = invoice_scan_path

    if payment_receipt_scan and payment_receipt_scan.filename:
        payment_receipt_scan_path = save_uploaded_scan(payment_receipt_scan)
        if payment_receipt_scan_path is None:
            flash('Скан чека об оплате должен быть изображением JPG, JPEG, PNG, GIF или WEBP', 'danger')
            return redirect(url_for('sale_detail', sale_id=sale.id))
        sale.payment_receipt_scan_path = payment_receipt_scan_path

    sale.sale_state = 'Завершена'
    sale.sale_date = now_vladivostok()

    add_product_status_history_if_changed(sale.product, 'Продан')
    set_all_ads_to_sold(sale.product_id)

    in_type_id = get_fin_type_id_by_code('IN')
    sale_article_id = get_article_id_by_name('продажа')

    last_ad = Advertisement.query.filter_by(product_id=sale.product_id).order_by(Advertisement.created_at.desc()).first()

    sale_amount = None
    if last_ad and last_ad.ad_price is not None:
        sale_amount = float(last_ad.ad_price)

    finance_created = False

    if not in_type_id:
        flash('Не найден тип финансовой операции IN. Проверьте справочник fin_type.', 'danger')
    elif not sale_article_id:
        flash('Не найдена статья "продажа". Проверьте справочник article.', 'danger')
    elif sale_amount is None or sale_amount <= 0:
        flash('Не удалось создать доход: у товара нет объявления с корректной ценой продажи.', 'danger')
    else:
        db.session.add(Finance(
            type=in_type_id,
            op_date=now_vladivostok(),
            article=sale_article_id,
            amount=sale_amount,
            product_id=sale.product_id,
            sale_id=sale.id,
            comment='Автоматически создано при завершении сделки'
        ))
        finance_created = True

    db.session.commit()

    if finance_created:
        flash('Сделка успешно завершена, доход по продаже добавлен', 'success')
    else:
        flash('Сделка завершена, но запись о доходе не была создана', 'warning')

    return redirect(url_for('sale_detail', sale_id=sale.id))

@app.route('/sales/<int:sale_id>/cancel', methods=['POST'])
def cancel_sale(sale_id):
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    sale = Sale.query.get_or_404(sale_id)

    if sale.sale_state != 'Активна':
        flash('Отменить можно только активную сделку', 'danger')
        return redirect(url_for('sale_detail', sale_id=sale.id))

    sale.sale_state = 'Отменена'
    sale.sale_date = None

    restored_ad = restore_advertisement_after_sale_cancel(sale.product_id)

    if restored_ad:
        add_product_status_history_if_changed(sale.product, 'Опубликован')
    else:
        add_product_status_history_if_changed(sale.product, 'Готов к продаже')

    db.session.commit()

    flash('Сделка отменена. Можно создать новую сделку по этому товару.', 'success')
    return redirect(url_for('sale_detail', sale_id=sale.id))

@app.route('/sales')
def sales():
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    state = request.args.get('state', '').strip()

    query = Sale.query.join(Product).join(Buyer)

    if state:
        query = query.filter(Sale.sale_state == state)

    sale_list = query.order_by(Sale.sale_begin_date.desc()).all()
    return render_template('sales.html', sales=sale_list, state=state, states=AVAILABLE_SALE_STATES)

@app.route('/reports')
def reports():
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    date_from = request.args.get('date_from', '').strip()
    date_to = request.args.get('date_to', '').strip()

    products_sort = request.args.get('products_sort', 'id_desc').strip()
    products_status = request.args.get('products_status', '').strip()
    products_category_id = request.args.get('products_category_id', '').strip()

    sold_sort = request.args.get('sold_sort', 'sale_date_desc').strip()
    sold_category_id = request.args.get('sold_category_id', '').strip()

    sales_sort = request.args.get('sales_sort', 'date_desc').strip()
    sales_state = request.args.get('sales_state', '').strip()
    sales_channel = request.args.get('sales_channel', '').strip()

    finances_sort = request.args.get('finances_sort', 'date_desc').strip()
    finances_type = request.args.get('finances_type', '').strip()
    finances_article_id = request.args.get('finances_article_id', '').strip()
    finances_product_id = request.args.get('finances_product_id', '').strip()

    expense_sort = request.args.get('expense_sort', 'amount_desc').strip()
    channel_sort = request.args.get('channel_sort', 'count_desc').strip()
    buyer_sales_sort = request.args.get('buyer_sales_sort', 'amount_desc').strip()
    profit_sort = request.args.get('profit_sort', 'profit_desc').strip()
    category_profit_sort = request.args.get('category_profit_sort', 'profit_desc').strip()

    show_products = request.args.get('show_products') == '1'
    show_sold_products = request.args.get('show_sold_products') == '1'
    show_sales = request.args.get('show_sales') == '1'
    show_finances = request.args.get('show_finances') == '1'
    show_expense_articles = request.args.get('show_expense_articles') == '1'
    show_sales_channels = request.args.get('show_sales_channels') == '1'
    show_buyers_analytics = request.args.get('show_buyers_analytics') == '1'
    show_profit = request.args.get('show_profit') == '1'
    show_category_profit = request.args.get('show_category_profit') == '1'

    date_from_value = None
    date_to_value = None

    try:
        if date_from:
            date_from_value = datetime.strptime(date_from, '%Y-%m-%d')
        if date_to:
            date_to_value = datetime.strptime(date_to, '%Y-%m-%d').replace(hour=23, minute=59, second=59)
    except ValueError:
        flash('Некорректный формат даты в фильтре отчетов', 'danger')

    base_products_query = Product.query.join(Category)
    base_sales_query = Sale.query.join(Product).join(Buyer)
    base_finances_query = Finance.query.join(FinType).join(Article)
    ads_query = Advertisement.query

    if date_from_value:
        base_sales_query = base_sales_query.filter(Sale.sale_begin_date >= date_from_value)
        base_finances_query = base_finances_query.filter(Finance.op_date >= date_from_value)
        ads_query = ads_query.filter(Advertisement.created_at >= date_from_value)

    if date_to_value:
        base_sales_query = base_sales_query.filter(Sale.sale_begin_date <= date_to_value)
        base_finances_query = base_finances_query.filter(Finance.op_date <= date_to_value)
        ads_query = ads_query.filter(Advertisement.created_at <= date_to_value)

    # Сводка
    all_products = Product.query.all()
    all_sales = base_sales_query.order_by(Sale.sale_begin_date.desc()).all()
    all_finances = base_finances_query.order_by(Finance.op_date.desc()).all()
    advertisements = ads_query.order_by(Advertisement.created_at.desc()).all()

    income_total = 0.0
    expense_total = 0.0
    for item in all_finances:
        if item.fin_type.type == 'IN':
            income_total += float(item.amount)
        elif item.fin_type.type == 'OUT':
            expense_total += float(item.amount)

    summary = {
        'products_count': len(all_products),
        'active_ads_count': sum(1 for ad in advertisements if ad.ad_status == 'Активно'),
        'active_sales_count': sum(1 for sale in all_sales if sale.sale_state == 'Активна'),
        'completed_sales_count': sum(1 for sale in all_sales if sale.sale_state == 'Завершена'),
        'income_total': income_total,
        'expense_total': expense_total,
        'profit_total': income_total - expense_total,
        'repair_count': sum(1 for product in all_products if product.current_status == 'В ремонте'),
        'reserved_count': sum(1 for product in all_products if product.current_status == 'Зарезервирован'),
        'sold_count': sum(1 for product in all_products if product.current_status == 'Продан')
    }

    # Товары
    products_query = base_products_query
    if products_status:
        products_query = products_query.filter(Product.current_status == products_status)
    if products_category_id:
        try:
            products_query = products_query.filter(Product.category_id == int(products_category_id))
        except ValueError:
            pass

    if products_sort == 'id_asc':
        products_query = products_query.order_by(Product.id.asc())
    elif products_sort == 'price_asc':
        products_query = products_query.order_by(Product.purchase_price.asc())
    elif products_sort == 'price_desc':
        products_query = products_query.order_by(Product.purchase_price.desc())
    elif products_sort == 'status_asc':
        products_query = products_query.order_by(Product.current_status.asc())
    else:
        products_query = products_query.order_by(Product.id.desc())

    products = products_query.all()

    # Проданные товары
    sold_sales_query = base_sales_query.filter(Sale.sale_state == 'Завершена')
    if sold_category_id:
        try:
            sold_sales_query = sold_sales_query.filter(Product.category_id == int(sold_category_id))
        except ValueError:
            pass

    sold_products = sold_sales_query.all()
    if sold_sort == 'id_asc':
        sold_products.sort(key=lambda x: x.product.id if x.product else 0)
    elif sold_sort == 'id_desc':
        sold_products.sort(key=lambda x: x.product.id if x.product else 0, reverse=True)
    elif sold_sort == 'sale_date_asc':
        sold_products.sort(key=lambda x: x.sale_date or datetime.min)
    else:
        sold_products.sort(key=lambda x: x.sale_date or datetime.min, reverse=True)

    # Сделки
    sales_query = base_sales_query
    if sales_state:
        sales_query = sales_query.filter(Sale.sale_state == sales_state)
    if sales_channel:
        sales_query = sales_query.filter(Sale.channel == sales_channel)

    if sales_sort == 'id_asc':
        sales_query = sales_query.order_by(Sale.id.asc())
    elif sales_sort == 'id_desc':
        sales_query = sales_query.order_by(Sale.id.desc())
    elif sales_sort == 'date_asc':
        sales_query = sales_query.order_by(Sale.sale_begin_date.asc())
    else:
        sales_query = sales_query.order_by(Sale.sale_begin_date.desc())

    sales = sales_query.all()

    # Финансы
    finances_query = base_finances_query
    if finances_type:
        finances_query = finances_query.filter(FinType.type == finances_type)
    if finances_article_id:
        try:
            finances_query = finances_query.filter(Finance.article == int(finances_article_id))
        except ValueError:
            pass
    if finances_product_id:
        try:
            finances_query = finances_query.filter(Finance.product_id == int(finances_product_id))
        except ValueError:
            pass

    if finances_sort == 'id_asc':
        finances_query = finances_query.order_by(Finance.id.asc())
    elif finances_sort == 'id_desc':
        finances_query = finances_query.order_by(Finance.id.desc())
    elif finances_sort == 'amount_asc':
        finances_query = finances_query.order_by(Finance.amount.asc())
    elif finances_sort == 'amount_desc':
        finances_query = finances_query.order_by(Finance.amount.desc())
    elif finances_sort == 'date_asc':
        finances_query = finances_query.order_by(Finance.op_date.asc())
    else:
        finances_query = finances_query.order_by(Finance.op_date.desc())

    finances = finances_query.all()

    # Расходы по статьям
    expense_by_article = {}
    for item in all_finances:
        if item.fin_type.type == 'OUT':
            article_name = item.article_ref.article
            expense_by_article.setdefault(article_name, 0.0)
            expense_by_article[article_name] += float(item.amount)

    expense_by_article_rows = [
        {'article': article, 'amount': amount}
        for article, amount in expense_by_article.items()
    ]
    if expense_sort == 'amount_asc':
        expense_by_article_rows.sort(key=lambda x: x['amount'])
    elif expense_sort == 'article_asc':
        expense_by_article_rows.sort(key=lambda x: x['article'])
    else:
        expense_by_article_rows.sort(key=lambda x: x['amount'], reverse=True)

    # Сделки по каналам
    sales_by_channel = {}
    for sale in all_sales:
        channel_name = sale.channel.strip() if sale.channel else 'Не указан'
        sales_by_channel.setdefault(channel_name, 0)
        sales_by_channel[channel_name] += 1

    sales_by_channel_rows = [
        {'channel': channel, 'count': count}
        for channel, count in sales_by_channel.items()
    ]
    if channel_sort == 'channel_asc':
        sales_by_channel_rows.sort(key=lambda x: x['channel'])
    else:
        sales_by_channel_rows.sort(key=lambda x: x['count'], reverse=True)

    # Сделки по покупателям
    buyer_sales_rows = build_buyer_sales_rows(all_sales)
    if buyer_sales_sort == 'amount_asc':
        buyer_sales_rows.sort(key=lambda x: x['amount'])
    elif buyer_sales_sort == 'count_desc':
        buyer_sales_rows.sort(key=lambda x: x['count'], reverse=True)
    elif buyer_sales_sort == 'count_asc':
        buyer_sales_rows.sort(key=lambda x: x['count'])
    elif buyer_sales_sort == 'buyer_asc':
        buyer_sales_rows.sort(key=lambda x: x['buyer'].full_name.lower())
    else:
        buyer_sales_rows.sort(key=lambda x: x['amount'], reverse=True)

    # Прибыль по товарам
    product_profit_rows = []
    for product in Product.query.order_by(Product.id.desc()).all():
        expense_sum = 0.0
        income_sum = 0.0

        for fin in product.finances:
            if date_from_value and fin.op_date < date_from_value:
                continue
            if date_to_value and fin.op_date > date_to_value:
                continue

            if fin.fin_type.type == 'OUT':
                expense_sum += float(fin.amount)
            elif fin.fin_type.type == 'IN':
                income_sum += float(fin.amount)

        product_profit_rows.append({
            'product': product,
            'expense': expense_sum,
            'income': income_sum,
            'profit': income_sum - expense_sum
        })

    if profit_sort == 'profit_asc':
        product_profit_rows.sort(key=lambda x: x['profit'])
    elif profit_sort == 'income_desc':
        product_profit_rows.sort(key=lambda x: x['income'], reverse=True)
    elif profit_sort == 'expense_desc':
        product_profit_rows.sort(key=lambda x: x['expense'], reverse=True)
    else:
        product_profit_rows.sort(key=lambda x: x['profit'], reverse=True)

    # Прибыль по категориям
    category_profit_map = {}
    for product in Product.query.join(Category).all():
        category_name = product.category.name
        category_profit_map.setdefault(category_name, {
            'category': category_name,
            'expense': 0.0,
            'income': 0.0,
            'profit': 0.0
        })

        for fin in product.finances:
            if date_from_value and fin.op_date < date_from_value:
                continue
            if date_to_value and fin.op_date > date_to_value:
                continue

            if fin.fin_type.type == 'OUT':
                category_profit_map[category_name]['expense'] += float(fin.amount)
            elif fin.fin_type.type == 'IN':
                category_profit_map[category_name]['income'] += float(fin.amount)

    category_profit_rows = list(category_profit_map.values())
    for row in category_profit_rows:
        row['profit'] = row['income'] - row['expense']

    if category_profit_sort == 'profit_asc':
        category_profit_rows.sort(key=lambda x: x['profit'])
    elif category_profit_sort == 'income_desc':
        category_profit_rows.sort(key=lambda x: x['income'], reverse=True)
    elif category_profit_sort == 'expense_desc':
        category_profit_rows.sort(key=lambda x: x['expense'], reverse=True)
    else:
        category_profit_rows.sort(key=lambda x: x['profit'], reverse=True)

    categories = Category.query.order_by(Category.name.asc()).all()
    articles = Article.query.order_by(Article.article.asc()).all()
    finance_products = Product.query.order_by(Product.id.desc()).all()
    sale_channels = sorted({sale.channel for sale in Sale.query.all() if sale.channel})

    filters = {
        'date_from': date_from,
        'date_to': date_to,
        'products_sort': products_sort,
        'products_status': products_status,
        'products_category_id': products_category_id,
        'sold_sort': sold_sort,
        'sold_category_id': sold_category_id,
        'sales_sort': sales_sort,
        'sales_state': sales_state,
        'sales_channel': sales_channel,
        'finances_sort': finances_sort,
        'finances_type': finances_type,
        'finances_article_id': finances_article_id,
        'finances_product_id': finances_product_id,
        'expense_sort': expense_sort,
        'channel_sort': channel_sort,
        'buyer_sales_sort': buyer_sales_sort,
        'profit_sort': profit_sort,
        'category_profit_sort': category_profit_sort,
        'show_products': show_products,
        'show_sold_products': show_sold_products,
        'show_sales': show_sales,
        'show_finances': show_finances,
        'show_expense_articles': show_expense_articles,
        'show_sales_channels': show_sales_channels,
        'show_buyers_analytics': show_buyers_analytics,
        'show_profit': show_profit,
        'show_category_profit': show_category_profit
    }

    return render_template(
        'reports.html',
        summary=summary,
        products=products,
        sales=sales,
        finances=finances,
        sold_products=sold_products,
        product_profit_rows=product_profit_rows,
        category_profit_rows=category_profit_rows,
        expense_by_article_rows=expense_by_article_rows,
        sales_by_channel_rows=sales_by_channel_rows,
        buyer_sales_rows=buyer_sales_rows,
        filters=filters,
        categories=categories,
        articles=articles,
        finance_products=finance_products,
        sale_channels=sale_channels,
        statuses=AVAILABLE_STATUSES + ['Опубликован'],
        sale_states=AVAILABLE_SALE_STATES
    )
    
@app.route('/reports/export/xlsx')
def export_reports_xlsx():
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    data = build_reports_data(request.args)

    wb = Workbook()
    ws = wb.active
    ws.title = 'Сводка'

    row = 1
    ws.cell(row=row, column=1, value='Аналитическая сводка')
    row += 2

    summary = data['summary']
    summary_rows = [
        ('Количество товаров', summary['products_count']),
        ('Активные объявления', summary['active_ads_count']),
        ('Активные сделки', summary['active_sales_count']),
        ('Завершенные сделки', summary['completed_sales_count']),
        ('Доходы', summary['income_total']),
        ('Расходы', summary['expense_total']),
        ('Финансовый результат', summary['profit_total']),
        ('Товаров в ремонте', summary['repair_count']),
        ('Товаров зарезервировано', summary['reserved_count']),
        ('Товаров продано', summary['sold_count']),
    ]

    for title, value in summary_rows:
        ws.cell(row=row, column=1, value=title)
        ws.cell(row=row, column=2, value=value)
        row += 1

    if data['filters']['show_products']:
        ws2 = wb.create_sheet('Товары')
        headers = ['ID', 'Категория', 'Производитель', 'Модель', 'Статус', 'Закупочная цена']
        for col, header in enumerate(headers, start=1):
            ws2.cell(row=1, column=col, value=header)
        for r, product in enumerate(data['products'], start=2):
            ws2.cell(r, 1, product.id)
            ws2.cell(r, 2, product.category.name)
            ws2.cell(r, 3, product.manufacturer)
            ws2.cell(r, 4, product.model)
            ws2.cell(r, 5, product.current_status)
            ws2.cell(r, 6, float(product.purchase_price) if product.purchase_price is not None else None)

    if data['filters']['show_sold_products']:
        ws3 = wb.create_sheet('Проданные товары')
        headers = ['ID товара', 'Товар', 'Покупатель', 'Дата начала сделки', 'Дата продажи']
        for col, header in enumerate(headers, start=1):
            ws3.cell(row=1, column=col, value=header)
        for r, sale in enumerate(data['sold_products'], start=2):
            ws3.cell(r, 1, sale.product.id)
            ws3.cell(r, 2, f'{sale.product.manufacturer} {sale.product.model}')
            ws3.cell(r, 3, sale.buyer.full_name)
            ws3.cell(r, 4, sale.sale_begin_date.strftime('%d.%m.%Y %H:%M:%S'))
            ws3.cell(r, 5, sale.sale_date.strftime('%d.%m.%Y %H:%M:%S') if sale.sale_date else '')

    if data['filters']['show_sales']:
        ws4 = wb.create_sheet('Сделки')
        headers = ['ID', 'Товар', 'Покупатель', 'Статус', 'Дата начала', 'Дата завершения', 'Канал']
        for col, header in enumerate(headers, start=1):
            ws4.cell(row=1, column=col, value=header)
        for r, sale in enumerate(data['sales'], start=2):
            ws4.cell(r, 1, sale.id)
            ws4.cell(r, 2, f'{sale.product.manufacturer} {sale.product.model}')
            ws4.cell(r, 3, sale.buyer.full_name)
            ws4.cell(r, 4, sale.sale_state)
            ws4.cell(r, 5, sale.sale_begin_date.strftime('%d.%m.%Y %H:%M:%S'))
            ws4.cell(r, 6, sale.sale_date.strftime('%d.%m.%Y %H:%M:%S') if sale.sale_date else '')
            ws4.cell(r, 7, sale.channel or '')

    if data['filters']['show_finances']:
        ws5 = wb.create_sheet('Финансы')
        headers = ['ID', 'Дата', 'Тип', 'Статья', 'Сумма', 'Комментарий']
        for col, header in enumerate(headers, start=1):
            ws5.cell(row=1, column=col, value=header)
        for r, item in enumerate(data['finances'], start=2):
            ws5.cell(r, 1, item.id)
            ws5.cell(r, 2, item.op_date.strftime('%d.%m.%Y %H:%M:%S'))
            ws5.cell(r, 3, item.fin_type.type)
            ws5.cell(r, 4, item.article_ref.article)
            ws5.cell(r, 5, float(item.amount))
            ws5.cell(r, 6, item.comment or '')

    if data['filters']['show_expense_articles']:
        ws6 = wb.create_sheet('Расходы по статьям')
        ws6.cell(1, 1, 'Статья')
        ws6.cell(1, 2, 'Сумма')
        for r, row_data in enumerate(data['expense_by_article_rows'], start=2):
            ws6.cell(r, 1, row_data['article'])
            ws6.cell(r, 2, row_data['amount'])

    if data['filters']['show_sales_channels']:
        ws7 = wb.create_sheet('Сделки по каналам')
        ws7.cell(1, 1, 'Канал')
        ws7.cell(1, 2, 'Количество сделок')
        for r, row_data in enumerate(data['sales_by_channel_rows'], start=2):
            ws7.cell(r, 1, row_data['channel'])
            ws7.cell(r, 2, row_data['count'])

    if data['filters']['show_buyers_analytics']:
        ws8 = wb.create_sheet('Покупатели')
        headers = ['ID покупателя', 'Покупатель', 'Контакты', 'Количество сделок', 'Сумма сделок']
        for col, header in enumerate(headers, start=1):
            ws8.cell(row=1, column=col, value=header)
        for r, row_data in enumerate(data['buyer_sales_rows'], start=2):
            ws8.cell(r, 1, row_data['buyer'].id)
            ws8.cell(r, 2, row_data['buyer'].full_name)
            ws8.cell(r, 3, row_data['buyer'].contact_info)
            ws8.cell(r, 4, row_data['count'])
            ws8.cell(r, 5, row_data['amount'])

    if data['filters']['show_profit']:
        ws9 = wb.create_sheet('Прибыль по товарам')
        headers = ['ID товара', 'Товар', 'Расходы', 'Доходы', 'Результат']
        for col, header in enumerate(headers, start=1):
            ws9.cell(row=1, column=col, value=header)
        for r, row_data in enumerate(data['product_profit_rows'], start=2):
            ws9.cell(r, 1, row_data['product'].id)
            ws9.cell(r, 2, f"{row_data['product'].manufacturer} {row_data['product'].model}")
            ws9.cell(r, 3, row_data['expense'])
            ws9.cell(r, 4, row_data['income'])
            ws9.cell(r, 5, row_data['profit'])

    output = BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name='reports.xlsx',
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@app.route('/reports/export/pdf')
def export_reports_pdf():
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    data = build_reports_data(request.args)

    output = BytesIO()
    pdf = canvas.Canvas(output, pagesize=landscape(A4))
    width, height = landscape(A4)

    font_path = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    pdfmetrics.registerFont(TTFont('DejaVuSans', font_path))
    pdf.setFont('DejaVuSans', 12)

    y = height - 40
    pdf.drawString(30, y, 'Аналитическая сводка')
    y -= 30

    summary = data['summary']
    lines = [
        f"Количество товаров: {summary['products_count']}",
        f"Активные объявления: {summary['active_ads_count']}",
        f"Активные сделки: {summary['active_sales_count']}",
        f"Завершенные сделки: {summary['completed_sales_count']}",
        f"Доходы: {summary['income_total']:.2f}",
        f"Расходы: {summary['expense_total']:.2f}",
        f"Финансовый результат: {summary['profit_total']:.2f}",
        f"Товаров в ремонте: {summary['repair_count']}",
        f"Товаров зарезервировано: {summary['reserved_count']}",
        f"Товаров продано: {summary['sold_count']}",
    ]

    for line in lines:
        pdf.drawString(30, y, line)
        y -= 20

    selected_sections = []
    if data['filters']['show_products']:
        selected_sections.append('Товары')
    if data['filters']['show_sold_products']:
        selected_sections.append('Проданные товары')
    if data['filters']['show_sales']:
        selected_sections.append('Сделки')
    if data['filters']['show_finances']:
        selected_sections.append('Финансы')
    if data['filters']['show_expense_articles']:
        selected_sections.append('Расходы по статьям')
    if data['filters']['show_sales_channels']:
        selected_sections.append('Сделки по каналам')
    if data['filters']['show_buyers_analytics']:
        selected_sections.append('Покупатели')
    if data['filters']['show_profit']:
        selected_sections.append('Прибыль по товарам')

    y -= 20
    pdf.drawString(30, y, 'Выбранные аналитические блоки:')
    y -= 20

    for section in selected_sections:
        pdf.drawString(50, y, f'- {section}')
        y -= 18
        if y < 40:
            pdf.showPage()
            pdf.setFont('DejaVuSans', 12)
            y = height - 40

    pdf.save()
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name='reports.pdf',
        mimetype='application/pdf'
    )
    
@app.route('/finances', methods=['GET', 'POST'])
def finances():
    if session.get('role') not in ['ip', 'admin']:
        return redirect(url_for('login'))

    fin_types = FinType.query.order_by(FinType.id.asc()).all()
    articles = Article.query.order_by(Article.article.asc()).all()
    products = Product.query.order_by(Product.id.desc()).all()
    sales_list = Sale.query.order_by(Sale.id.desc()).all()

    date_from = request.args.get('date_from', '').strip()
    date_to = request.args.get('date_to', '').strip()
    prefill_repair = request.args.get('prefill_repair', '').strip()
    prefill_product_id = request.args.get('product_id', '').strip()

    if request.method == 'POST':
        form_data = build_finance_form_data(request.form)

        type_id = form_data['type']
        op_date = form_data['op_date']
        article_id = form_data['article']
        amount = form_data['amount']
        product_id = form_data['product_id']
        sale_id = form_data['sale_id']
        comment = form_data['comment']

        if not type_id or not article_id or not amount:
            flash('Заполните обязательные поля финансовой операции', 'danger')
        else:
            try:
                amount_value = float(amount)
                if amount_value <= 0:
                    flash('Сумма операции должна быть больше 0', 'danger')
                else:
                    op_date_value = now_vladivostok()

                    if product_id:
                        product_exists = Product.query.get(product_id)
                        if not product_exists:
                            flash('Указанный товар не найден', 'danger')
                            raise ValueError

                    if sale_id:
                        sale_exists = Sale.query.get(sale_id)
                        if not sale_exists:
                            flash('Указанная сделка не найдена', 'danger')
                            raise ValueError

                    new_finance = Finance(
                        type=int(type_id),
                        op_date=op_date_value,
                        article=int(article_id),
                        amount=amount_value,
                        product_id=int(product_id) if product_id else None,
                        sale_id=int(sale_id) if sale_id else None,
                        comment=comment or None
                    )

                    db.session.add(new_finance)
                    db.session.commit()

                    flash('Финансовая операция успешно добавлена', 'success')
                    return redirect(url_for('finances'))

            except ValueError:
                if not get_flashed_messages():
                    flash('Проверьте корректность даты и суммы', 'danger')

        query = Finance.query.join(FinType).join(Article)
        try:
            if date_from:
                date_from_value = datetime.strptime(date_from, '%Y-%m-%d')
                query = query.filter(Finance.op_date >= date_from_value)

            if date_to:
                date_to_value = datetime.strptime(date_to, '%Y-%m-%d').replace(hour=23, minute=59, second=59)
                query = query.filter(Finance.op_date <= date_to_value)
        except ValueError:
            flash('Некорректный формат даты в фильтре', 'danger')

        finance_list = query.order_by(Finance.op_date.desc()).all()

        return render_template(
            'finances.html',
            finance_form=form_data,
            finances=finance_list,
            fin_types=fin_types,
            articles=articles,
            products=products,
            sales_list=sales_list,
            filters={'date_from': date_from, 'date_to': date_to}
        )

    query = Finance.query.join(FinType).join(Article)

    try:
        if date_from:
            date_from_value = datetime.strptime(date_from, '%Y-%m-%d')
            query = query.filter(Finance.op_date >= date_from_value)

        if date_to:
            date_to_value = datetime.strptime(date_to, '%Y-%m-%d')
            date_to_value = date_to_value.replace(hour=23, minute=59, second=59)
            query = query.filter(Finance.op_date <= date_to_value)
    except ValueError:
        flash('Некорректный формат даты в фильтре', 'danger')

    finance_list = query.order_by(Finance.op_date.desc()).all()

    empty_form = {
    'type': '',
    'op_date': to_datetime_local_value(now_vladivostok()),
    'article': '',
    'amount': '',
    'product_id': '',
    'sale_id': '',
    'comment': ''
}

    if prefill_repair == '1':
        out_type_id = get_fin_type_id_by_code('OUT')
        repair_article_id = get_article_id_by_name('ремонт')

        empty_form['type'] = str(out_type_id) if out_type_id else ''
        empty_form['article'] = str(repair_article_id) if repair_article_id else ''
        empty_form['product_id'] = prefill_product_id
        empty_form['comment'] = 'Расход на ремонт товара'

    return render_template(
        'finances.html',
        finance_form=empty_form,
        finances=finance_list,
        fin_types=fin_types,
        articles=articles,
        products=products,
        sales_list=sales_list,
        filters={'date_from': date_from, 'date_to': date_to}
    )


def normalize_phone(value):
    digits = re.sub(r'\D', '', value or '')

    if not digits:
        return ''

    if digits.startswith('8'):
        digits = '7' + digits[1:]

    if not digits.startswith('7'):
        digits = '7' + digits

    digits = digits[:11]

    if len(digits) != 11:
        return ''

    return f'+7({digits[1:4]})-{digits[4:7]}-{digits[7:9]}-{digits[9:11]}'

def build_product_form_data(request_form, image_path=None):
    return {
        'category_id': request_form.get('category_id', '').strip(),
        'warehouse_id': request_form.get('warehouse_id', '').strip(),
        'manufacturer': request_form.get('manufacturer', '').strip(),
        'model': request_form.get('model', '').strip(),
        'purchase_price': request_form.get('purchase_price', '').strip(),
        'image_path': image_path,
        'specifications': request_form.get('specifications', '').strip(),
        'condition_rate': request_form.get('condition_rate', '').strip(),
        'current_status': request_form.get('current_status', '').strip(),
        'comments': request_form.get('comments', '').strip(),
    }
    
def build_advertisement_form_data(request_form, product):
    default_title = f'{product.manufacturer} {product.model}'.strip()

    description_parts = []
    if product.specifications:
        description_parts.append(product.specifications)
    if product.comments:
        description_parts.append(f'Комментарий: {product.comments}')

    default_description = '\n\n'.join(description_parts).strip()

    return {
        'platform': request_form.get('platform', '').strip(),
        'ad_price': request_form.get('ad_price', '').strip(),
        'title': request_form.get('title', default_title).strip() or default_title,
        'description': request_form.get('description', default_description).strip() or default_description,
        'media_urls': request_form.get('media_urls', '').strip(),
        'ad_status': request_form.get('ad_status', 'Активно').strip() or 'Активно',
        'ad_url': request_form.get('ad_url', '').strip(),
    }

def serialize_advertisement_form_data(advertisement):
    return {
        'id': advertisement.id,
        'platform': advertisement.platform or '',
        'ad_price': str(advertisement.ad_price) if advertisement.ad_price is not None else '',
        'title': advertisement.title or '',
        'description': advertisement.description or '',
        'media_urls': advertisement.media_urls or '',
        'ad_status': advertisement.ad_status or '',
        'ad_url': advertisement.ad_url or '',
    }

def build_advertisement_form_context(product, advertisement, is_edit=False, advertisement_record=None):
    return {
        'product': product,
        'advertisement': advertisement,
        'platforms': AVAILABLE_AD_PLATFORMS,
        'ad_statuses': AVAILABLE_AD_STATUSES,
        'is_edit': is_edit,
        'advertisement_record': advertisement_record,
        'sale': get_current_sale_for_product(product)
    }

def create_test_users():
    admin_exists = User.query.filter_by(username='admin').first()
    ip_exists = User.query.filter_by(username='ip_user').first()

    if not admin_exists:
        db.session.add(User(username='admin', password='123', role='admin'))

    if not ip_exists:
        db.session.add(User(username='ip_user', password='123', role='ip'))

    db.session.commit()
    
def get_fin_type_id_by_code(code):
    fin_type = FinType.query.filter_by(type=code).first()
    return fin_type.id if fin_type else None


def get_article_id_by_name(name):
    article = Article.query.filter_by(article=name).first()
    return article.id if article else None


def to_datetime_local_value(dt):
    if not dt:
        return ''
    return dt.strftime('%Y-%m-%dT%H:%M')

def create_default_categories():
    default_categories = [
        'Электроника',
        'Инструменты',
        'Бытовая техника',
        'Комплектующие'
    ]

    for category_name in default_categories:
        exists = Category.query.filter_by(name=category_name).first()
        if not exists:
            db.session.add(Category(name=category_name))

    db.session.commit()

def ensure_sales_table_schema():
    columns = {
        row[1]
        for row in db.session.execute(text("PRAGMA table_info(sales)")).fetchall()
    }

    needs_rebuild = False
    index_rows = db.session.execute(text("PRAGMA index_list(sales)")).fetchall()
    for index_row in index_rows:
        index_name = index_row[1]
        is_unique = bool(index_row[2])
        if not is_unique:
            continue

        indexed_columns = [
            item[2]
            for item in db.session.execute(text(f"PRAGMA index_info('{index_name}')")).fetchall()
        ]
        if indexed_columns == ['product_id']:
            needs_rebuild = True
            break

    if needs_rebuild:
        invoice_select = 'invoice_scan_path' if 'invoice_scan_path' in columns else 'NULL AS invoice_scan_path'
        receipt_select = (
            'payment_receipt_scan_path'
            if 'payment_receipt_scan_path' in columns
            else 'NULL AS payment_receipt_scan_path'
        )

        db.session.execute(text('PRAGMA foreign_keys=OFF'))
        db.session.execute(text("""
            CREATE TABLE sales_new (
                id INTEGER PRIMARY KEY,
                product_id INTEGER NOT NULL,
                buyer_id INTEGER NOT NULL,
                sale_state VARCHAR(50) NOT NULL,
                sale_begin_date DATETIME NOT NULL,
                sale_date DATETIME,
                channel VARCHAR(100),
                sale_comment TEXT,
                invoice_scan_path TEXT,
                payment_receipt_scan_path TEXT,
                FOREIGN KEY(product_id) REFERENCES products(id),
                FOREIGN KEY(buyer_id) REFERENCES buyers(id)
            )
        """))
        db.session.execute(text(f"""
            INSERT INTO sales_new (
                id, product_id, buyer_id, sale_state, sale_begin_date,
                sale_date, channel, sale_comment, invoice_scan_path, payment_receipt_scan_path
            )
            SELECT
                id, product_id, buyer_id, sale_state, sale_begin_date,
                sale_date, channel, sale_comment, {invoice_select}, {receipt_select}
            FROM sales
        """))
        db.session.execute(text('DROP TABLE sales'))
        db.session.execute(text('ALTER TABLE sales_new RENAME TO sales'))
        db.session.execute(text('PRAGMA foreign_keys=ON'))
        db.session.commit()
        columns = {
            row[1]
            for row in db.session.execute(text("PRAGMA table_info(sales)")).fetchall()
        }

    if 'invoice_scan_path' not in columns:
        db.session.execute(text('ALTER TABLE sales ADD COLUMN invoice_scan_path TEXT'))

    if 'payment_receipt_scan_path' not in columns:
        db.session.execute(text('ALTER TABLE sales ADD COLUMN payment_receipt_scan_path TEXT'))

    db.session.commit()


if __name__ == '__main__':
    with app.app_context():
        ensure_upload_folder()
        db.create_all()
        ensure_sales_table_schema()
        create_test_users()
        create_default_categories()
        create_default_fin_types()
        create_default_articles()

    app.run(debug=True)
